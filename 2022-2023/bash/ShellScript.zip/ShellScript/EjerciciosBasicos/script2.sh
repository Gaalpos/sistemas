#!/bin/bash
num1=13
num2=78

echo $num2
