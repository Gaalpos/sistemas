#!/bin/bash
numeros=(09 08 2000 20 04)
echo ${numeros[*]}
numeritos=("${numeros[@]}")
echo ${numeritos[*]}
