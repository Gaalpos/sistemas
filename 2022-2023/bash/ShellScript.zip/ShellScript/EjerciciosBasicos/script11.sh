#!/bin/bash
echo "Se han pasado un total de $# marcas"
echo "La marca introducida en segundo lugar es: $2"
