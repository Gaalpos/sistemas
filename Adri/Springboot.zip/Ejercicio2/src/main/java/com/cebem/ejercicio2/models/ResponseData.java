package com.cebem.ejercicio2.models;

public class ResponseData {
    public String translatedText;
}
