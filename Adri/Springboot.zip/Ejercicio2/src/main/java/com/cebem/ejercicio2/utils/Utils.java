package com.cebem.ejercicio2.utils;

public class Utils {


    public static String toUpper(String word){
        return word.toUpperCase();
    }
    
}
