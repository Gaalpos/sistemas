package com.cebem.ejercicio2.models;

public class Translation{
   public ResponseData responseData;
}