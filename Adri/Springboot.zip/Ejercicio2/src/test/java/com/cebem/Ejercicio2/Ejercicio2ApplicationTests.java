package com.cebem.Ejercicio2;

import com.cebem.ejercicio2.controllers.Ejercicio2;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicio2ApplicationTests {

	@Autowired
	Ejercicio2 ejercicio2;

	@Test
	void contextLoads() {
	}

}
