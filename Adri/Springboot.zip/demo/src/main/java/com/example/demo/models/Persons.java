package com.example.demo.models;

import java.util.ArrayList;

public class Persons {
    public ArrayList<Person> results;
}
