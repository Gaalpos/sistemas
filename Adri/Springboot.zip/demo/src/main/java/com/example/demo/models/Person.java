package com.example.demo.models;

public class Person {
    public String name;
    public String image;
}
